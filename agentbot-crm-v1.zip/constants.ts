
import { Property, Lead, Client, Visit, DashboardStats, ChatMessage, LeadHistory, ClientStatus, SalesStage } from './types';

// --- DATA GENERATORS ---
const NAMES = ['Juan', 'Maria', 'Carlos', 'Ana', 'Luis', 'Sofia', 'Miguel', 'Lucia', 'Pedro', 'Elena'];
const SURNAMES = ['Garcia', 'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Gonzalez', 'Perez', 'Sanchez'];

const CLIENT_STATUSES: ClientStatus[] = ['frio', 'interesado', 'en_seguimiento', 'cerrado', 'derivacion_humano', 'rechazado'];
const SALES_STAGES: SalesStage[] = ['inicio', 'indagacion', 'bajada_producto', 'pre_cierre', 'cierre', 'derivacion_humano', 'visita_agendada'];

// PROPERTIES
export const MOCK_PROPERTIES: Property[] = [
  {
    id: 'p1',
    titulo: 'Moderna Casa en Nordelta',
    descripcion: 'Espectacular casa al lago central, 4 dormitorios en suite, piscina infinita. Diseño minimalista con acabados de hormigón a la vista y madera.',
    direccion: 'Av. Del Golf 230',
    barrio: 'Nordelta',
    ciudad: 'Tigre',
    provincia: 'Buenos Aires',
    precio: 850000,
    moneda: 'USD',
    tipo_operacion: 'venta',
    tipo_inmueble: 'casa',
    estado_publicacion: 'publicada',
    ambientes: 6,
    dormitorios: 4,
    banos: 5,
    cocheras: 3,
    superficie_total: 450,
    superficie_cubierta: 380,
    amenities: ['Piscina', 'SUM', 'Gimnasio', 'Seguridad'],
    imagen_principal: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1000&auto=format&fit=crop',
    origen: 'propia',
    leads_interesados_count: 14,
    created_at: '2023-10-01',
    updated_at: '2023-10-01',
  },
  {
    id: 'p2',
    titulo: 'Piso Exclusivo Recoleta',
    descripcion: 'Piso de categoría sobre Av. Alvear. Palier privado, vista a parques. Pisos de roble de Eslavonia y molduras originales.',
    direccion: 'Av. Alvear 1800',
    barrio: 'Recoleta',
    ciudad: 'CABA',
    provincia: 'Buenos Aires',
    precio: 1200000,
    moneda: 'USD',
    tipo_operacion: 'venta',
    tipo_inmueble: 'departamento',
    estado_publicacion: 'publicada',
    ambientes: 5,
    dormitorios: 3,
    banos: 3,
    cocheras: 2,
    superficie_total: 280,
    superficie_cubierta: 260,
    imagen_principal: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=1000&auto=format&fit=crop',
    origen: 'propia',
    leads_interesados_count: 8,
    created_at: '2023-10-02',
    updated_at: '2023-10-02',
  },
  {
    id: 'p3',
    titulo: 'Loft Industrial Palermo Soho',
    descripcion: 'Ex fábrica reciclada. Doble altura, grandes ventanales de hierro repartido. Ideal estudio profesional o vivienda.',
    direccion: 'Niceto Vega 5500',
    barrio: 'Palermo',
    ciudad: 'CABA',
    provincia: 'Buenos Aires',
    precio: 250000,
    moneda: 'USD',
    tipo_operacion: 'venta',
    tipo_inmueble: 'ph',
    estado_publicacion: 'reservada',
    ambientes: 2,
    dormitorios: 1,
    banos: 2,
    cocheras: 1,
    superficie_total: 90,
    superficie_cubierta: 90,
    imagen_principal: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?q=80&w=1000&auto=format&fit=crop',
    origen: 'propia',
    leads_interesados_count: 22,
    created_at: '2023-10-03',
    updated_at: '2023-10-03',
  }
];

export const MOCK_LEADS: Lead[] = Array.from({ length: 20 }, (_, i) => {
  const name = `${NAMES[i % NAMES.length]} ${SURNAMES[i % SURNAMES.length]}`;
  return {
    id: `lead-${i + 1}`,
    nombre: name,
    telefono: `+54 9 11 ${1000 + i}-${2000 + i}`,
    email: `${name.toLowerCase().replace(' ', '.')}@email.com`,
    tipo_operacion_preferida: i % 2 === 0 ? 'venta' : 'alquiler',
    rango_presupuesto_min: 100000,
    rango_presupuesto_max: 500000,
    zonas_preferidas: ['Palermo', 'Recoleta', 'Nordelta'],
    tipo_inmueble_preferido: i % 3 === 0 ? 'casa' : 'departamento',
    estado_lead: CLIENT_STATUSES[i % CLIENT_STATUSES.length],
    etapa_venta: SALES_STAGES[i % SALES_STAGES.length],
    temperatura: i % 3 === 0 ? 'caliente' : (i % 2 === 0 ? 'tibio' : 'frio'),
    score_interes: Math.floor(Math.random() * 6) + 4,
    fuente: 'portales',
    property_interes_ids: ['p1', 'p2'],
    created_at: '2023-10-25T10:00:00Z',
    updated_at: '2023-10-25T10:00:00Z',
    ai_summary: i % 2 === 0 
      ? "Cliente con alto potencial. Busca activamente en zona norte para mudanza familiar rápida. Ha consultado 3 veces por la misma unidad." 
      : "Inversor institucional analizado. Prioriza rentabilidad en CABA. Comportamiento defensivo con las contraofertas.",
    notas: "Prefiere contacto por WhatsApp después de las 18hs. No molestar por la mañana.",
    tags: ['Familia', 'Urgencia', 'Zona Norte', 'Inversor'],
    history: [
      { id: 'h1', type: 'stage_change', date: '2023-10-25 09:30', title: 'Ingreso de Lead', description: 'Lead ingresado vía Zonaprop por la unidad Nordelta.', user_name: 'System' },
      { id: 'h2', type: 'stage_change', date: '2023-10-25 10:05', title: 'Calificación IA', description: 'AgentBot identificó requerimientos de venta y presupuesto USD 300k+.', user_name: 'AgentBot' },
      { id: 'h3', type: 'communication', date: '2023-10-26 14:20', title: 'WhatsApp Respondido', description: 'El cliente solicita brochure y planos de la unidad.', user_name: 'Carolina Mendes' },
    ],
    transcript: [
      { id: 'm1', sender: 'user', text: 'Hola, vi la casa en Nordelta. ¿Sigue disponible?', timestamp: '14:20' },
      { id: 'bot', sender: 'bot', text: '¡Hola! Sí, sigue disponible. Es una de nuestras unidades más exclusivas. ¿Te gustaría coordinar una visita o recibir más información?', timestamp: '14:21' },
      { id: 'm2', sender: 'user', text: 'Me gustaría visitarla el sábado si es posible.', timestamp: '14:25' },
    ]
  };
});

export const MOCK_CLIENTS: Client[] = MOCK_LEADS.map(l => ({
  ...l,
  tipo_cliente: 'comprador',
  estado_comercial: 'activo'
}));

export const MOCK_STATS: DashboardStats = {
  totalLeads: 1245,
  qualifiedLeads: 350,
  visitsScheduled: 42,
  dealsClosed: 15,
  negotiationAmount: 8500000,
};

export const MOCK_VISITS: Visit[] = [
  {
    id: 'v1',
    lead_id: 'lead-1',
    lead_nombre: 'Juan Garcia',
    property_id: 'p1',
    property_titulo: 'Moderna Casa en Nordelta',
    vendedor_id: 'agent-1',
    fecha: '2023-11-05',
    hora: '10:00',
    estado: 'agendada',
    pipeline_stage: 'pendiente',
    created_at: '2023-10-25',
    updated_at: '2023-10-25'
  }
];