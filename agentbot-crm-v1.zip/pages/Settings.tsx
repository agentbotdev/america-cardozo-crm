import React from 'react';
import { Save, RefreshCw } from 'lucide-react';

const IntegrationCard = ({ title, description, children, onTest }: any) => (
  <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mb-6">
    <div className="flex justify-between items-start mb-4">
      <div>
        <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
        <p className="text-sm text-gray-500">{description}</p>
      </div>
      {onTest && (
        <button 
          onClick={onTest}
          className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
        >
          <RefreshCw size={14} /> Probar conexión
        </button>
      )}
    </div>
    <div className="space-y-4">
      {children}
    </div>
  </div>
);

const Settings: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto pb-10">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Configuración e Integraciones</h1>

      {/* Tokko Integration */}
      <IntegrationCard 
        title="Tokko Broker" 
        description="Conexión para importar propiedades y sincronizar estados."
        onTest={() => alert('TODO: Testing Tokko connection...')}
      >
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">API Key</label>
          <input 
            type="password" 
            defaultValue="tk_xxxxxxxxxxxxxxxx"
            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none font-mono"
          />
        </div>
      </IntegrationCard>

      {/* WhatsApp/Chatwoot Integration */}
      <IntegrationCard 
        title="WhatsApp Cloud API" 
        description="Gestión de mensajería automatizada y chatbots."
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number ID</label>
            <input type="text" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none" placeholder="102938..." />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">WABA ID</label>
            <input type="text" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none" placeholder="1029..." />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Permanent Access Token</label>
          <input type="password" className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none font-mono" />
        </div>
      </IntegrationCard>

      {/* General Settings */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Preferencias Generales</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Moneda por defecto</label>
            <select className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none bg-white">
              <option value="USD">Dólar Estadounidense (USD)</option>
              <option value="ARS">Peso Argentino (ARS)</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Zona Horaria</label>
            <select className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none bg-white">
              <option value="America/Argentina/Buenos_Aires">Buenos Aires (GMT-3)</option>
            </select>
          </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 md:pl-72 flex justify-end">
        <button className="bg-ios-blue text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-600 shadow-sm flex items-center gap-2">
          <Save size={18} />
          Guardar Cambios
        </button>
      </div>
    </div>
  );
};

export default Settings;