
import React, { useState, useMemo } from 'react';
import { MOCK_PROPERTIES } from '../constants';
import { Property } from '../types';
import { 
  Filter, Plus, MapPin, Search, X, Heart, 
  BedDouble, Bath, Ruler, LayoutGrid, Map as MapIcon, 
  ArrowLeft, ChevronLeft, ChevronRight, Share2, Home, Info, Layers, MapPinned, Sparkles, 
  Clock, Building2
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// --- SHARED UI SUB-COMPONENTS ---

const TabButton = ({ active, onClick, icon: Icon, label }: any) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-2.5 px-6 py-3.5 rounded-full text-xs font-black uppercase tracking-widest transition-all duration-300 whitespace-nowrap flex-shrink-0
      ${active 
        ? 'bg-slate-900 text-white shadow-2xl scale-105 ring-8 ring-white' 
        : 'bg-white text-slate-400 hover:bg-slate-50 hover:text-slate-900 border border-slate-100 hover:shadow-md'
      }`}
  >
    <Icon size={16} />
    {label}
  </button>
);

const InfoCard = ({ icon: Icon, label, value, color = 'indigo' }: any) => (
  <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center gap-5 hover:shadow-xl transition-all duration-500 hover:-translate-y-2 group">
    <div className={`p-4 bg-${color}-50 text-${color}-600 rounded-[1.5rem] group-hover:scale-110 transition-transform shadow-inner`}>
      <Icon size={24} />
    </div>
    <div className="min-w-0">
      <p className="text-xl font-black text-slate-900 leading-none truncate tracking-tight">{value}</p>
      <p className="text-[10px] text-slate-400 uppercase font-black mt-1.5 tracking-widest truncate">{label}</p>
    </div>
  </div>
);

// --- 1. REFINED PROPERTY CARD ---
const PropertyCard = React.memo(({ property, onView }: any) => {
  const [isFavorite, setIsFavorite] = useState(false);
  
  const statusColors: Record<string, string> = {
    publicada: 'bg-emerald-500',
    pausada: 'bg-amber-500',
    reservada: 'bg-orange-500',
    vendida: 'bg-slate-500',
    alquilada: 'bg-purple-600'
  };

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-[3rem] overflow-hidden group shadow-sm hover:shadow-2xl hover:shadow-slate-200/50 border border-slate-100 flex flex-col h-full relative transform-gpu transition-all duration-500"
    >
      <div className="h-64 sm:h-72 w-full bg-slate-100 relative overflow-hidden cursor-pointer" onClick={() => onView(property)}>
        <img 
          src={property.imagen_principal} 
          alt={property.titulo} 
          className="w-full h-full object-cover transition-transform duration-1000 ease-[cubic-bezier(0.23,1,0.32,1)] group-hover:scale-110"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/10 to-transparent opacity-70 group-hover:opacity-85 transition-opacity"></div>
        
        <div className="absolute top-5 left-5 flex flex-col gap-2 z-10">
          <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-[0.2em] text-white shadow-xl backdrop-blur-md ring-1 ring-white/30 ${statusColors[property.estado_publicacion] || 'bg-slate-500'}`}>
            {property.estado_publicacion}
          </span>
          <span className="px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-[0.2em] bg-white/95 text-slate-900 shadow-xl backdrop-blur-md w-fit ring-1 ring-black/5">
            {property.tipo_operacion}
          </span>
        </div>

        <button 
            onClick={(e) => { e.stopPropagation(); setIsFavorite(!isFavorite); }}
            className={`absolute top-5 right-5 p-3 rounded-full backdrop-blur-md transition-all duration-500 shadow-2xl ring-1 ring-white/30 active:scale-75 z-10
                ${isFavorite ? 'bg-rose-500 text-white border-rose-400 shadow-rose-200' : 'bg-white/20 text-white hover:bg-white hover:text-rose-500 border-white/40'}`}
        >
            <Heart size={22} fill={isFavorite ? "currentColor" : "none"} strokeWidth={3} />
        </button>
        
        <div className="absolute bottom-6 left-8 right-8 text-white z-10 pointer-events-none">
             <div className="flex items-baseline gap-1.5 mb-2">
                 <span className="text-sm font-black text-slate-300">{property.moneda}</span>
                 <p className="text-4xl font-black tracking-tighter drop-shadow-2xl">
                    {property.precio.toLocaleString()}
                 </p>
             </div>
             <p className="text-[11px] font-black uppercase tracking-[0.2em] text-slate-200 flex items-center gap-2 truncate drop-shadow-lg">
                 <MapPin size={14} className="text-indigo-400 shrink-0" /> {property.barrio}
             </p>
        </div>
      </div>
      
      <div className="p-8 flex flex-col flex-1">
        <h3 className="text-xl font-black text-slate-900 mb-6 line-clamp-1 group-hover:text-indigo-600 transition-colors leading-tight tracking-tight" title={property.titulo}>
            {property.titulo}
        </h3>

        <div className="grid grid-cols-3 gap-4 mb-8">
            <div className="flex flex-col items-center justify-center p-4 bg-slate-50/50 rounded-[2rem] border border-slate-100 group-hover:bg-white group-hover:shadow-md transition-all duration-500">
                <BedDouble size={22} className="text-indigo-600 mb-2.5" />
                <span className="text-base font-black text-slate-900">{property.dormitorios || 0}</span>
                <span className="text-[9px] text-slate-400 font-black uppercase tracking-[0.2em] mt-1">Dorms</span>
            </div>
            <div className="flex flex-col items-center justify-center p-4 bg-slate-50/50 rounded-[2rem] border border-slate-100 group-hover:bg-white group-hover:shadow-md transition-all duration-500">
                <Bath size={22} className="text-indigo-600 mb-2.5" />
                <span className="text-base font-black text-slate-900">{property.banos || 0}</span>
                <span className="text-[9px] text-slate-400 font-black uppercase tracking-[0.2em] mt-1">Baños</span>
            </div>
            <div className="flex flex-col items-center justify-center p-4 bg-slate-50/50 rounded-[2rem] border border-slate-100 group-hover:bg-white group-hover:shadow-md transition-all duration-500">
                <Ruler size={22} className="text-indigo-600 mb-2.5" />
                <span className="text-base font-black text-slate-900">{property.superficie_total}</span>
                <span className="text-[9px] text-slate-400 font-black uppercase tracking-[0.2em] mt-1">m²</span>
            </div>
        </div>
        
        <div className="mt-auto pt-6 flex items-center justify-between border-t border-slate-100/50">
           <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-[1rem] bg-slate-900 flex items-center justify-center text-white text-[11px] font-black border-2 border-white shadow-lg">
                  AB
              </div>
              <div className="flex flex-col">
                  <span className="text-[9px] text-slate-400 font-black uppercase tracking-widest leading-none mb-1">Responsable</span>
                  <span className="text-[11px] text-slate-900 font-black leading-none">Carolina Mendes</span>
              </div>
           </div>
           <button 
                onClick={(e) => { e.stopPropagation(); onView(property); }} 
                className="p-4 bg-slate-900 text-white rounded-2xl hover:bg-indigo-600 transition-all duration-300 shadow-xl hover:shadow-indigo-200 active:scale-90"
            >
                <ChevronRight size={18} strokeWidth={3.5}/>
           </button>
        </div>
      </div>
    </motion.div>
  );
});

// --- 2. PROPERTY DETAIL VIEW ---
const PropertyDetailView = ({ property, onClose }: any) => {
    const [activeTab, setActiveTab] = useState<'resumen' | 'descripcion' | 'caracteristicas' | 'amenities' | 'ubicacion'>('resumen');
    const [currentImageIndex, setCurrentImageIndex] = useState(0);
    const images = property.imagenes && property.imagenes.length > 0 ? property.imagenes : [property.imagen_principal || ''];

    const nextImage = () => setCurrentImageIndex((prev) => (prev + 1) % images.length);
    const prevImage = () => setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);

    return (
        <div className="fixed inset-0 z-[120] flex flex-col bg-[#F8FAFC] animate-fade-in overflow-hidden">
            <button 
              onClick={onClose} 
              className="fixed top-8 right-8 z-[150] bg-slate-900 text-white p-4 rounded-[1.5rem] shadow-2xl hover:bg-indigo-600 transition-all active:scale-90"
            >
              <X size={26} strokeWidth={3} />
            </button>

            <div className="flex-1 overflow-y-auto no-scrollbar">
                <div className="relative h-[55vh] md:h-[70vh] bg-slate-900 shrink-0 group">
                    <img src={images[currentImageIndex]} className="w-full h-full object-cover opacity-85 transition-all duration-700" alt={property.titulo} />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-95"></div>
                    
                    {images.length > 1 && (
                        <div className="absolute inset-y-0 left-0 right-0 flex items-center justify-between px-8 pointer-events-none">
                            <button onClick={prevImage} className="pointer-events-auto bg-white/10 hover:bg-white/30 text-white p-6 rounded-[2rem] backdrop-blur-2xl transition-all opacity-0 group-hover:opacity-100 shadow-2xl active:scale-90"><ChevronLeft size={32} strokeWidth={3}/></button>
                            <button onClick={nextImage} className="pointer-events-auto bg-white/10 hover:bg-white/30 text-white p-6 rounded-[2rem] backdrop-blur-2xl transition-all opacity-0 group-hover:opacity-100 shadow-2xl active:scale-90"><ChevronRight size={32} strokeWidth={3}/></button>
                        </div>
                    )}

                    <div className="absolute bottom-0 left-0 right-0 p-8 md:p-16 z-10">
                        <div className="flex flex-col md:flex-row justify-between items-end gap-10 max-w-7xl mx-auto">
                            <div className="text-white max-w-3xl">
                                <div className="flex gap-3 mb-6">
                                    <span className="bg-indigo-600 px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.3em] shadow-2xl ring-1 ring-white/20">{property.tipo_operacion}</span>
                                    <span className="bg-white/10 backdrop-blur-xl px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.3em] ring-1 ring-white/10">{property.tipo_inmueble}</span>
                                </div>
                                <h1 className="text-4xl md:text-7xl font-black leading-[1.1] mb-5 tracking-tighter drop-shadow-2xl">{property.titulo}</h1>
                                <p className="text-slate-300 flex items-center gap-3 text-lg md:text-2xl font-bold tracking-tight opacity-90">
                                  <MapPin size={24} className="text-indigo-500 shrink-0 shadow-sm"/> {property.direccion}, {property.barrio}
                                </p>
                            </div>
                            <div className="bg-white/95 backdrop-blur-2xl text-slate-900 px-12 py-8 rounded-[3.5rem] shadow-2xl border border-white hidden md:block ring-[12px] ring-white/10 transform hover:scale-105 transition-transform duration-500">
                                <p className="text-[11px] font-black text-slate-400 uppercase mb-2 tracking-[0.3em]">Precio de Lista</p>
                                <p className="text-6xl font-black tracking-tighter text-slate-900">
                                  <span className="text-2xl font-black mr-2 text-slate-300">{property.moneda}</span>
                                  {property.precio.toLocaleString()}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-white border-b border-slate-100 sticky top-0 z-50 shadow-sm overflow-x-auto no-scrollbar py-6">
                    <div className="max-w-7xl mx-auto px-8 flex gap-4">
                        <TabButton active={activeTab === 'resumen'} onClick={() => setActiveTab('resumen')} icon={Home} label="Vista General" />
                        <TabButton active={activeTab === 'descripcion'} onClick={() => setActiveTab('descripcion')} icon={Info} label="Descripción" />
                        <TabButton active={activeTab === 'caracteristicas'} onClick={() => setActiveTab('caracteristicas')} icon={Layers} label="Ficha Técnica" />
                        <TabButton active={activeTab === 'amenities'} onClick={() => setActiveTab('amenities')} icon={Sparkles} label="Comodidades" />
                        <TabButton active={activeTab === 'ubicacion'} onClick={() => setActiveTab('ubicacion')} icon={MapPinned} label="Geolocalización" />
                    </div>
                </div>

                <div className="max-w-7xl mx-auto p-8 md:p-16 pb-40">
                    {activeTab === 'resumen' && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 animate-slide-up">
                            <InfoCard icon={BedDouble} label="Dormitorios" value={property.dormitorios || 0} />
                            <InfoCard icon={Bath} label="Baños" value={property.banos || 0} />
                            <InfoCard icon={Ruler} label="Superficie Total" value={`${property.superficie_total} m²`} />
                            <InfoCard icon={Home} label="Cantidad Ambientes" value={property.ambientes || '-'} />
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const Properties = () => {
  const [activeType, setActiveType] = useState<'published' | 'acquisition'>('published');
  const [viewMode, setViewMode] = useState<'grid' | 'map'>('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [viewingProp, setViewingProp] = useState<Property | null>(null);
  const [sortBy, setSortBy] = useState<'price_asc' | 'price_desc' | 'date_new' | 'date_old'>('date_new');

  const displayedProps = useMemo(() => {
    let props = MOCK_PROPERTIES.filter(p => activeType === 'published' ? p.estado_publicacion !== 'borrador' : p.estado_publicacion === 'borrador');
    
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      props = props.filter(p => p.titulo.toLowerCase().includes(q) || p.barrio.toLowerCase().includes(q));
    }

    return [...props].sort((a, b) => {
        switch (sortBy) {
            case 'price_asc': return a.precio - b.precio;
            case 'price_desc': return b.precio - a.precio;
            case 'date_new': return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
            case 'date_old': return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
            default: return 0;
        }
    });
  }, [activeType, searchTerm, sortBy]);

  return (
    <div className="max-w-[1600px] mx-auto animate-fade-in pb-24 px-4 md:px-0 transform-gpu">
      <AnimatePresence>
        {viewingProp && <PropertyDetailView property={viewingProp} onClose={() => setViewingProp(null)} />}
      </AnimatePresence>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-16 gap-10">
        <div>
          <h1 className="text-5xl lg:text-7xl font-black text-slate-900 tracking-tighter leading-none mb-4">Stock Inmobiliario</h1>
          <p className="text-slate-400 font-bold text-lg uppercase tracking-[0.2em]">Gestión profesional de activos y captación de mercado.</p>
        </div>
        <button className="w-full md:w-auto flex items-center justify-center gap-3 bg-slate-900 text-white px-10 py-6 rounded-[2.5rem] font-black text-[12px] uppercase tracking-[0.3em] hover:bg-indigo-600 transition-all shadow-2xl active:scale-95 shadow-slate-200">
          <Plus size={22} strokeWidth={3} /> NUEVA UNIDAD
        </button>
      </div>

      <div className="flex flex-col lg:flex-row justify-between items-center mb-12 gap-6 bg-white p-3 rounded-[3rem] border border-slate-100 shadow-sm">
          <div className="bg-slate-100/50 p-2 rounded-[2.5rem] flex w-full lg:w-auto border border-slate-100">
              <button onClick={() => setActiveType('published')} className={`px-10 py-3.5 rounded-[2rem] text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${activeType === 'published' ? 'bg-white text-slate-900 shadow-xl ring-1 ring-black/5' : 'text-slate-400 hover:text-slate-600'}`}>Unidades Publicadas</button>
              <button onClick={() => setActiveType('acquisition')} className={`px-10 py-3.5 rounded-[2rem] text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${activeType === 'acquisition' ? 'bg-white text-slate-900 shadow-xl ring-1 ring-black/5' : 'text-slate-400 hover:text-slate-600'}`}>Captación Activa</button>
          </div>

          <div className="flex flex-wrap items-center gap-4 w-full lg:w-auto px-4 lg:px-0">
             <div className="flex-1 lg:flex-none flex items-center bg-slate-50/50 rounded-full px-8 py-4 border border-slate-100 focus-within:ring-[12px] focus-within:ring-indigo-50/50 focus-within:bg-white lg:w-96 transition-all group">
                <Search size={20} className="text-slate-400 mr-4 group-focus-within:text-indigo-500 transition-colors" />
                <input 
                    type="text" 
                    placeholder="Busca por barrio, calle o título..." 
                    className="bg-transparent border-none outline-none text-sm font-bold text-slate-700 w-full placeholder:text-slate-300"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
             </div>

             <div className="relative">
                <select 
                    value={sortBy} 
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="bg-white border border-slate-200 text-[10px] font-black uppercase tracking-widest text-slate-500 rounded-[1.5rem] px-8 py-4.5 outline-none hover:border-indigo-200 transition-all shadow-sm cursor-pointer appearance-none min-w-[200px]"
                >
                    <option value="date_new">Agregados Recientemente</option>
                    <option value="date_old">Más Antiguos</option>
                    <option value="price_desc">Precio: Más Caro</option>
                    <option value="price_asc">Precio: Más Barato</option>
                </select>
             </div>

             <div className="bg-slate-50 p-1.5 rounded-[1.8rem] flex border border-slate-100 shadow-inner">
                  <button onClick={() => setViewMode('grid')} className={`p-4 rounded-2xl transition-all ${viewMode === 'grid' ? 'bg-white text-indigo-600 shadow-lg' : 'text-slate-300'}`}><LayoutGrid size={22}/></button>
                  <button onClick={() => setViewMode('map')} className={`p-4 rounded-2xl transition-all ${viewMode === 'map' ? 'bg-white text-indigo-600 shadow-lg' : 'text-slate-300'}`}><MapIcon size={22}/></button>
             </div>
             
             <button className="p-5 bg-white border border-slate-100 rounded-[1.8rem] text-slate-500 hover:text-indigo-600 transition-all shadow-sm active:scale-90 group">
                <Filter size={24} className="group-hover:rotate-12 transition-transform" />
             </button>
          </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10 animate-slide-up">
        {displayedProps.map(prop => (
          <PropertyCard key={prop.id} property={prop} onView={setViewingProp} />
        ))}
        {displayedProps.length === 0 && (
            <div className="col-span-full py-48 text-center bg-white rounded-[4rem] border-2 border-dashed border-slate-100">
                <Building2 size={80} className="mx-auto mb-10 text-slate-100 animate-pulse" />
                <p className="text-slate-400 font-black uppercase tracking-[0.4em] text-xl">Sin unidades encontradas</p>
                <button onClick={() => { setSearchTerm(''); setActiveType('published'); }} className="mt-8 text-indigo-600 font-black uppercase text-[11px] tracking-widest hover:underline">Limpiar todos los filtros</button>
            </div>
        )}
      </div>
    </div>
  );
};

export default Properties;
