import React, { useState } from 'react';
import { MOCK_VISITS } from '../constants';
import { Visit, VisitStatus } from '../types';
import { Calendar as CalendarIcon, Clock, MapPin, CheckCircle, Plus, LayoutList, CalendarDays, X, Check, Map, User, ChevronLeft, ChevronRight } from 'lucide-react';

const VisitFormModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={onClose}></div>
            <div className="glass-modal w-full max-w-lg rounded-3xl shadow-2xl relative animate-fade-in p-8">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-bold text-gray-800">Agendar Visita</h2>
                    <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors" aria-label="Cerrar"><X size={20}/></button>
                </div>
                <div className="space-y-4">
                     <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Lead / Cliente</label>
                        <select className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none">
                            <option>Juan Pérez</option>
                            <option>Ana Gómez</option>
                        </select>
                    </div>
                     <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Propiedad</label>
                        <select className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none">
                            <option>Depto Premium Recoleta</option>
                            <option>Casa Minimalista Lagos</option>
                        </select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                         <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Fecha</label>
                            <input type="date" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-100" />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Hora</label>
                            <input type="time" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-100" />
                        </div>
                    </div>
                </div>
                 <div className="mt-8 flex gap-3">
                    <button onClick={onClose} className="flex-1 py-3 rounded-xl text-sm font-bold text-gray-600 hover:bg-gray-100">Cancelar</button>
                    <button onClick={() => { alert('Visita agendada'); onClose(); }} className="flex-1 py-3 rounded-xl text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-lg shadow-indigo-200">Agendar</button>
                </div>
            </div>
        </div>
    )
}

const VisitDetailPanel: React.FC<{ visit: Visit; onClose: () => void }> = ({ visit, onClose }) => {
    return (
        <div className="fixed inset-y-0 right-0 w-full md:w-[500px] bg-white/95 backdrop-blur-xl shadow-2xl z-50 transform transition-transform duration-500 animate-slide-in-right p-8 border-l border-white/50 flex flex-col">
            <div className="flex justify-between items-start mb-8">
                 <div>
                     <h2 className="text-xl font-bold text-gray-800">Detalle de Visita</h2>
                     <p className="text-sm text-gray-500">ID: {visit.id}</p>
                </div>
                <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full" aria-label="Cerrar"><X size={20}/></button>
            </div>

            <div className="space-y-6 flex-1 overflow-y-auto">
                 {/* Main Info */}
                 <div className="glass-card p-6 rounded-2xl">
                     <h3 className="text-lg font-bold text-gray-800 mb-2">{visit.property_titulo}</h3>
                     <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                         <MapPin size={14}/> {visit.property_titulo} {/* Should be address */}
                     </div>
                     <div className="flex items-center gap-4 bg-gray-50 p-4 rounded-xl">
                         <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold">
                             {visit.lead_nombre.charAt(0)}
                         </div>
                         <div>
                             <p className="text-sm font-bold text-gray-800">{visit.lead_nombre}</p>
                             <p className="text-xs text-gray-500">Posible comprador</p>
                         </div>
                     </div>
                     <div className="mt-4 flex items-center gap-4 bg-white p-3 rounded-xl border border-gray-100">
                         <Clock className="text-gray-400"/>
                         <div>
                             <p className="text-sm font-bold text-gray-700">{visit.fecha}</p>
                             <p className="text-xs text-gray-500">{visit.hora} hs</p>
                         </div>
                     </div>
                 </div>

                 {/* Timeline / Status Tracking */}
                 <div className="glass-card p-6 rounded-2xl">
                     <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wide mb-6">Seguimiento</h3>
                     <div className="relative pl-6 border-l-2 border-indigo-100 space-y-8">
                         {visit.timeline?.map((event, idx) => (
                             <div key={event.id} className="relative">
                                 <div className="absolute -left-[29px] top-0 w-4 h-4 rounded-full bg-white border-4 border-indigo-400"></div>
                                 <div className="flex flex-col">
                                     <span className="text-xs font-bold text-indigo-400 mb-1">{event.timestamp}</span>
                                     <h4 className="text-sm font-bold text-gray-800 uppercase tracking-wide">{event.status}</h4>
                                     <p className="text-sm text-gray-600 mt-1">{event.comment}</p>
                                 </div>
                             </div>
                         ))}
                     </div>
                 </div>

                 {/* Actions */}
                 <div className="grid grid-cols-2 gap-4">
                     <button className="py-3 bg-green-50 text-green-700 rounded-xl font-bold text-xs hover:bg-green-100 flex items-center justify-center gap-2">
                         <Check size={14}/> Marcar Realizada
                     </button>
                     <button className="py-3 bg-red-50 text-red-700 rounded-xl font-bold text-xs hover:bg-red-100 flex items-center justify-center gap-2">
                         <X size={14}/> Cancelar
                     </button>
                 </div>
            </div>
        </div>
    )
}

// Full Month Calendar Grid
const CalendarGrid: React.FC<{ visits: Visit[]; onVisitClick: (v: Visit) => void }> = ({ visits, onVisitClick }) => {
    // Hardcoded for demo visualization (October/November split in prompt data)
    // In production, use date-fns to generate grid days dynamically
    const days = Array.from({ length: 35 }, (_, i) => {
        const d = new Date(2023, 9, 29); // Start around end of Oct
        d.setDate(d.getDate() + i);
        return d;
    });

    const getVisitsForDay = (date: Date) => {
        return visits.filter(v => {
             const vDate = new Date(v.fecha);
             return vDate.getDate() === date.getDate() && vDate.getMonth() === date.getMonth();
        });
    }

    return (
        <div className="glass-card rounded-3xl p-6 h-full flex flex-col">
            <div className="grid grid-cols-7 mb-4">
                {['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'].map(day => (
                    <div key={day} className="text-center text-xs font-bold text-gray-400 uppercase tracking-wider">{day}</div>
                ))}
            </div>
            <div className="grid grid-cols-7 flex-1 gap-2">
                {days.map((day, idx) => {
                    const dayVisits = getVisitsForDay(day);
                    const isToday = day.getDate() === new Date().getDate() && day.getMonth() === new Date().getMonth();

                    return (
                        <div key={idx} className={`min-h-[100px] border border-gray-100 rounded-xl p-2 bg-white/40 hover:bg-white transition-colors relative flex flex-col gap-1 ${day.getMonth() !== 9 && day.getMonth() !== 10 ? 'opacity-40' : ''}`}>
                            <span className={`text-xs font-bold mb-1 w-6 h-6 flex items-center justify-center rounded-full ${isToday ? 'bg-indigo-600 text-white' : 'text-gray-600'}`}>{day.getDate()}</span>
                            {dayVisits.map(v => (
                                <div 
                                    key={v.id} 
                                    onClick={() => onVisitClick(v)}
                                    className={`text-[10px] p-1.5 rounded-lg cursor-pointer font-bold truncate transition-all hover:scale-105 border-l-2 ${v.estado === 'confirmada' ? 'bg-green-50 text-green-700 border-green-500' : 'bg-indigo-50 text-indigo-700 border-indigo-500'}`}
                                >
                                    {v.hora} - {v.lead_nombre}
                                </div>
                            ))}
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

const Visits: React.FC = () => {
  const [view, setView] = useState<'calendar' | 'pipeline'>('calendar');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedVisit, setSelectedVisit] = useState<Visit | null>(null);

  // Mock Columns for Pipeline
  const pipelineStages = [
      { id: 'agendada', label: 'Agendadas', color: 'bg-blue-100 text-blue-700' },
      { id: 'confirmada', label: 'Confirmadas', color: 'bg-green-100 text-green-700' },
      { id: 'realizada', label: 'Realizadas', color: 'bg-gray-100 text-gray-700' }
  ];

  return (
    <div className="max-w-[1600px] mx-auto animate-fade-in pb-10">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-800 tracking-tight">Visitas</h1>
          <p className="text-gray-500 mt-1">Calendario y gestión de citas</p>
        </div>
        
        <div className="flex items-center gap-4">
             <div className="bg-gray-100/80 p-1 rounded-xl flex">
                <button 
                    onClick={() => setView('calendar')} 
                    className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all ${view === 'calendar' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500'}`}
                >
                    <CalendarDays size={16}/> Calendario
                </button>
                <button 
                    onClick={() => setView('pipeline')} 
                    className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition-all ${view === 'pipeline' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500'}`}
                >
                    <LayoutList size={16}/> Pipeline
                </button>
             </div>

            <button onClick={() => setIsModalOpen(true)} className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white px-5 py-3 rounded-2xl font-bold hover:shadow-xl hover:shadow-indigo-200 transition-all flex items-center gap-2">
              <Plus size={20} />
              Nueva Visita
            </button>
        </div>
      </div>

      <VisitFormModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
      {selectedVisit && (
          <>
            <div className="fixed inset-0 bg-black/20 z-40 backdrop-blur-sm" onClick={() => setSelectedVisit(null)}></div>
            <VisitDetailPanel visit={selectedVisit} onClose={() => setSelectedVisit(null)} />
          </>
      )}

      {view === 'calendar' ? (
          <CalendarGrid visits={MOCK_VISITS} onVisitClick={setSelectedVisit} />
      ) : (
          <div className="flex gap-6 overflow-x-auto pb-6 h-[calc(100vh-250px)]">
              {pipelineStages.map(stage => (
                  <div key={stage.id} className="min-w-[320px] bg-gray-50/50 border border-gray-100 rounded-3xl p-4 flex flex-col">
                      <div className="flex justify-between items-center mb-4 px-2">
                           <h3 className="font-bold text-gray-600 text-sm uppercase tracking-wide">{stage.label}</h3>
                           <span className="bg-white px-2 py-0.5 rounded text-xs font-bold text-gray-400">{MOCK_VISITS.filter(v => v.estado === stage.id).length}</span>
                      </div>
                      <div className="flex-1 space-y-3 overflow-y-auto">
                           {MOCK_VISITS.filter(v => v.estado === stage.id).map(visit => (
                               <div key={visit.id} onClick={() => setSelectedVisit(visit)} className="bg-white p-4 rounded-2xl shadow-sm hover:shadow-md cursor-pointer transition-all border border-transparent hover:border-indigo-100">
                                   <div className="text-xs font-bold text-indigo-500 mb-1">{visit.fecha} - {visit.hora}</div>
                                   <div className="font-bold text-gray-800 text-sm mb-2">{visit.lead_nombre}</div>
                                   <div className="text-xs text-gray-500 truncate">{visit.property_titulo}</div>
                               </div>
                           ))}
                      </div>
                  </div>
              ))}
          </div>
      )}
    </div>
  );
};

export default Visits;