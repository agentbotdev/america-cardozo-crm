
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, BrainCircuit, Home, ArrowRight, Users, MessageCircle, 
  Search, Clock, Plus, MapPin, CheckCircle2,
  Send, Smartphone, Mail, MoreVertical,
  Layers, Zap, Info, MessageSquare, Bot, Target
} from 'lucide-react';
import { MOCK_LEADS, MOCK_PROPERTIES } from '../constants';
import { Lead, ChatMessage } from '../types';

const statusColors = {
  frio: 'bg-blue-100 text-blue-600',
  tibio: 'bg-amber-100 text-amber-600',
  caliente: 'bg-rose-100 text-rose-600'
};

const stageColors = {
  inicio: 'bg-slate-100 text-slate-600',
  indagacion: 'bg-indigo-100 text-indigo-600',
  bajada_producto: 'bg-purple-100 text-purple-600',
  pre_cierre: 'bg-amber-100 text-amber-600',
  cierre: 'bg-emerald-100 text-emerald-600',
  derivacion_humano: 'bg-orange-100 text-orange-600',
  visita_agendada: 'bg-blue-100 text-blue-600',
};

// --- CHAT COMPONENTS ---

const ChatBubble: React.FC<{ message: ChatMessage; isLead: boolean }> = ({ message, isLead }) => {
  return (
    <div className={`flex w-full mb-5 px-1 ${isLead ? 'justify-start' : 'justify-end'}`}>
      <div className={`flex max-w-[82%] gap-3 ${isLead ? 'flex-row' : 'flex-row-reverse'}`}>
        <div className={`w-8 h-8 rounded-full shrink-0 flex items-center justify-center text-[10px] font-black shadow-sm mt-1
          ${isLead ? 'bg-white border border-slate-100 text-slate-400' : 'bg-slate-900 text-white shadow-lg'}`}>
          {isLead ? 'U' : <Bot size={14}/>}
        </div>
        <div className={`flex flex-col ${isLead ? 'items-start' : 'items-end'}`}>
          <div className={`px-5 py-3.5 rounded-[1.6rem] shadow-sm text-sm font-medium leading-relaxed relative
            ${isLead 
              ? 'bg-white border border-slate-100 text-slate-700 rounded-tl-none' 
              : 'bg-indigo-600 text-white rounded-tr-none shadow-indigo-100'}`}>
            {message.text}
          </div>
          <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest mt-2 px-1">
            {message.timestamp}
          </span>
        </div>
      </div>
    </div>
  );
};

export const LeadDetailPanel: React.FC<{ lead: Lead; onClose: () => void }> = ({ lead, onClose }) => {
  const [activeTab, setActiveTab] = useState<'info' | 'historial' | 'propiedades' | 'chat'>('info');
  const [message, setMessage] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const consultedProperties = useMemo(() => 
    MOCK_PROPERTIES.filter(p => lead.property_interes_ids?.includes(p.id)), 
    [lead.property_interes_ids]
  );

  useEffect(() => {
    if (activeTab === 'chat' && chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [activeTab, lead.transcript]);

  const handleSendMessage = () => {
    if (!message.trim()) return;
    // Logic for sending message would go here. For now, we clear the input.
    setMessage('');
  };

  return (
    <motion.div 
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 30, stiffness: 250 }}
      className="fixed inset-y-0 right-0 w-full md:w-[560px] bg-white shadow-2xl z-[100] flex flex-col border-l border-slate-200"
    >
      {/* Header */}
      <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-white shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-slate-900 text-white flex items-center justify-center font-black text-2xl shadow-xl ring-4 ring-slate-50 transition-transform hover:scale-105 cursor-default">
            {lead.nombre.charAt(0)}
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight leading-none mb-2">{lead.nombre}</h2>
            <div className="flex items-center gap-2">
               <span className={`px-2.5 py-1 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-sm ${statusColors[lead.temperatura]}`}>
                  {lead.temperatura}
               </span>
               <span className={`px-2.5 py-1 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-sm ${stageColors[lead.etapa_venta]}`}>
                  {lead.etapa_venta.replace('_', ' ')}
               </span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
            <button className="p-2.5 hover:bg-slate-50 rounded-xl transition-colors text-slate-300"><MoreVertical size={20}/></button>
            <button onClick={onClose} className="p-2.5 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all text-slate-600 active:scale-90"><X size={20}/></button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-100 bg-white shrink-0 overflow-x-auto no-scrollbar">
        {[
          { id: 'info', label: 'Perfil', icon: Info },
          { id: 'historial', label: 'Timeline', icon: Clock },
          { id: 'propiedades', label: 'Interés', icon: Home },
          { id: 'chat', label: 'Chat IA', icon: MessageSquare }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex-1 flex items-center justify-center gap-2.5 py-5 text-[10px] font-black uppercase tracking-[0.2em] transition-all relative whitespace-nowrap
              ${activeTab === tab.id ? 'text-indigo-600 bg-indigo-50/20' : 'text-slate-400 hover:text-slate-600'}`}
          >
            <tab.icon size={16} />
            {tab.label}
            {activeTab === tab.id && (
              <motion.div layoutId="lead-panel-tab" className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-t-full" />
            )}
          </button>
        ))}
      </div>

      {/* Main Panel Content */}
      <div className="flex-1 overflow-y-auto no-scrollbar bg-[#F8FAFC]">
        <AnimatePresence mode="wait">
          {activeTab === 'info' && (
            <motion.div key="info" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="p-8 space-y-8">
              <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white shadow-2xl relative overflow-hidden group border border-slate-800">
                <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:rotate-12 transition-transform duration-1000">
                  <BrainCircuit size={100}/>
                </div>
                <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-2.5 h-2.5 bg-emerald-400 rounded-full animate-pulse shadow-[0_0_10px_#10b981]"></div>
                    <span className="text-[10px] font-black tracking-[0.3em] uppercase text-slate-500">AgentBot Insight</span>
                  </div>
                  <p className="text-base font-bold leading-relaxed text-slate-100">
                    "{lead.ai_summary || "Perfil calificado automáticamente. Demuestra alto interés recurrente en zona norte."}"
                  </p>
                  <div className="mt-8 grid grid-cols-2 gap-5">
                     <div className="bg-white/5 p-4 rounded-2xl border border-white/5 backdrop-blur-sm">
                        <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1.5">Interés Score</p>
                        <p className="text-3xl font-black text-indigo-400">{lead.score_interes}/10</p>
                     </div>
                     <div className="bg-white/5 p-4 rounded-2xl border border-white/5 backdrop-blur-sm">
                        <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1.5">Próximo Paso</p>
                        <p className="text-xs font-bold text-slate-300 mt-1 uppercase tracking-tight">Cerrar Visita</p>
                     </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6">
                 <div className="bg-white p-7 rounded-[2rem] border border-slate-100 shadow-sm space-y-6">
                    <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] flex items-center gap-3">
                      <Target size={14} className="text-indigo-400"/> Preferencias del Prospecto
                    </h3>
                    <div className="grid grid-cols-2 gap-6">
                       <div className="space-y-1">
                          <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Búsqueda</p>
                          <p className="text-sm font-black text-slate-800">{lead.tipo_inmueble_preferido || 'Departamento'} • {lead.tipo_operacion_preferida.toUpperCase()}</p>
                       </div>
                       <div className="space-y-1">
                          <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Presupuesto</p>
                          <p className="text-sm font-black text-slate-800">USD {lead.rango_presupuesto_max?.toLocaleString()}</p>
                       </div>
                       <div className="space-y-1">
                          <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Zonas</p>
                          <p className="text-sm font-black text-slate-800 truncate">{lead.zonas_preferidas?.join(', ') || 'Cualquiera'}</p>
                       </div>
                    </div>
                 </div>

                 <div className="bg-white p-7 rounded-[2rem] border border-slate-100 shadow-sm space-y-6">
                    <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] flex items-center gap-3">
                      <Smartphone size={14} className="text-indigo-400"/> Datos de Contacto
                    </h3>
                    <div className="space-y-4">
                       <div className="flex items-center gap-4 p-3 bg-slate-50 rounded-2xl border border-slate-100 group cursor-pointer hover:bg-white transition-all">
                          <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center shadow-sm"><Smartphone size={18}/></div>
                          <span className="text-sm font-black text-slate-700">{lead.telefono}</span>
                       </div>
                       <div className="flex items-center gap-4 p-3 bg-slate-50 rounded-2xl border border-slate-100 group cursor-pointer hover:bg-white transition-all">
                          <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center shadow-sm"><Mail size={18}/></div>
                          <span className="text-sm font-black text-slate-700 truncate">{lead.email}</span>
                       </div>
                    </div>
                 </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'chat' && (
            <motion.div key="chat" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col h-full bg-[#F1F5F9]/40">
               <div className="flex-1 overflow-y-auto py-10 px-6 no-scrollbar scroll-smooth">
                  <div className="text-center mb-8">
                     <span className="text-[9px] font-black text-slate-300 uppercase tracking-[0.5em] bg-white px-4 py-1.5 rounded-full shadow-sm">Conversación Iniciada el 25 Oct</span>
                  </div>
                  {lead.transcript?.map(msg => (
                    <ChatBubble key={msg.id} message={msg} isLead={msg.sender === 'user'} />
                  ))}
                  <div ref={chatEndRef} />
               </div>
               <div className="p-6 bg-white border-t border-slate-100 flex gap-4 shrink-0 items-center shadow-2xl">
                  <div className="flex-1 relative group">
                    <input 
                      type="text" 
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                      placeholder="Escribe una respuesta asistida..." 
                      className="w-full bg-slate-50 border border-slate-200 rounded-[2rem] px-6 py-5 text-sm font-bold text-slate-700 outline-none focus:ring-[10px] focus:ring-indigo-50 focus:border-indigo-200 transition-all focus:bg-white"
                    />
                    <button className="absolute right-4 top-1/2 -translate-y-1/2 p-2.5 text-slate-300 hover:text-indigo-600 transition-colors group-hover:scale-110">
                       <Zap size={22} fill="currentColor" className="opacity-20 hover:opacity-100 transition-opacity" />
                    </button>
                  </div>
                  <button 
                    onClick={handleSendMessage}
                    className="w-16 h-16 bg-slate-900 text-white rounded-[1.8rem] flex items-center justify-center hover:bg-indigo-600 transition-all shadow-2xl active:scale-90 shrink-0"
                  >
                     <Send size={22} strokeWidth={2.5}/>
                  </button>
               </div>
            </motion.div>
          )}

          {activeTab === 'historial' && (
            <motion.div key="historial" initial={{ opacity: 0, x: 25 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="p-8">
               <div className="relative pl-8 border-l-2 border-slate-200 space-y-10">
                  {lead.history?.map((event) => (
                    <div key={event.id} className="relative group">
                       <div className="absolute -left-[41px] top-0 w-4 h-4 rounded-full bg-white border-4 border-indigo-500 shadow-lg transition-transform group-hover:scale-125 z-10"></div>
                       <div>
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1.5">{event.date}</p>
                          <h4 className="text-base font-black text-slate-800 tracking-tight leading-none mb-2">{event.title}</h4>
                          <p className="text-xs text-slate-500 font-bold mt-1 leading-relaxed">{event.description}</p>
                       </div>
                    </div>
                  ))}
               </div>
            </motion.div>
          )}

          {activeTab === 'propiedades' && (
            <motion.div key="propiedades" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="p-8 space-y-5">
               {consultedProperties.map(prop => (
                 <div key={prop.id} className="bg-white p-4 rounded-[2.2rem] border border-slate-100 shadow-sm flex gap-5 hover:border-indigo-200 hover:shadow-xl transition-all cursor-pointer group">
                    <div className="w-24 h-24 rounded-[1.8rem] overflow-hidden shrink-0 shadow-lg">
                       <img src={prop.imagen_principal} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt=""/>
                    </div>
                    <div className="flex-1 py-1 flex flex-col justify-between">
                       <div>
                          <h4 className="text-sm font-black text-slate-800 tracking-tight mb-1.5 group-hover:text-indigo-600 transition-colors leading-tight">{prop.titulo}</h4>
                          <p className="text-[10px] font-black text-slate-400 flex items-center gap-1.5 mt-1 uppercase tracking-widest"><MapPin size={12}/> {prop.barrio}</p>
                       </div>
                       <p className="text-base font-black text-slate-900 tracking-tight">{prop.moneda} {prop.precio.toLocaleString()}</p>
                    </div>
                    <div className="flex flex-col justify-center">
                        <div className="p-3 bg-slate-50 rounded-2xl text-slate-300 group-hover:text-indigo-600 transition-colors">
                            <ArrowRight size={20} strokeWidth={3}/>
                        </div>
                    </div>
                 </div>
               ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Footer Actions */}
      <div className="p-6 border-t border-slate-100 bg-white/95 backdrop-blur-xl shrink-0 flex gap-4">
          <button className="flex-1 py-5 bg-slate-900 text-white rounded-[1.8rem] font-black text-[11px] uppercase tracking-[0.3em] shadow-2xl hover:bg-indigo-600 transition-all flex items-center justify-center gap-3 active:scale-95 shadow-slate-300">
            <MessageCircle size={18} fill="currentColor" className="opacity-20"/> WHATSAPP DIRECTO
          </button>
          <button className="px-8 py-5 bg-slate-100 text-slate-600 rounded-[1.8rem] font-black text-[11px] uppercase tracking-[0.3em] hover:bg-slate-200 transition-all active:scale-95">
            AGENDAR
          </button>
      </div>
    </motion.div>
  );
};

const Leads: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [activeFilter, setActiveFilter] = useState<'todos' | 'caliente' | 'tibio' | 'frio'>('todos');
  const [sortBy, setSortBy] = useState<'date' | 'price_asc' | 'price_desc'>('date');

  const filteredLeads = useMemo(() => {
    let result = MOCK_LEADS.filter(lead => {
      const matchesSearch = lead.nombre.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesFilter = activeFilter === 'todos' || lead.temperatura === activeFilter;
      return matchesSearch && matchesFilter;
    });

    if (sortBy === 'price_asc') {
       result.sort((a, b) => (a.rango_presupuesto_max || 0) - (b.rango_presupuesto_max || 0));
    } else if (sortBy === 'price_desc') {
       result.sort((a, b) => (b.rango_presupuesto_max || 0) - (a.rango_presupuesto_max || 0));
    }
    return result;
  }, [searchTerm, activeFilter, sortBy]);

  return (
    <div className="max-w-[1600px] mx-auto animate-fade-in pb-16 transform-gpu px-4 md:px-0">
      <AnimatePresence>
        {selectedLead && (
          <>
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-900/10 backdrop-blur-[4px] z-[90]" 
              onClick={() => setSelectedLead(null)} 
            />
            <LeadDetailPanel lead={selectedLead} onClose={() => setSelectedLead(null)} />
          </>
        )}
      </AnimatePresence>

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-12 gap-8">
        <div>
          <h1 className="text-5xl lg:text-6xl font-black text-slate-900 tracking-tighter leading-none mb-3">Lead Pipeline</h1>
          <p className="text-slate-400 font-bold text-base uppercase tracking-[0.2em]">Gestión inteligente y calificación con AgentBot IA.</p>
        </div>
        <button className="w-full sm:w-auto bg-slate-900 text-white px-12 py-5 rounded-[2.5rem] font-black text-[12px] uppercase tracking-[0.3em] hover:bg-indigo-600 transition-all flex items-center justify-center gap-3 shadow-2xl shadow-slate-200 active:scale-95">
          <Plus size={20} strokeWidth={3} /> NUEVO LEAD
        </button>
      </div>

      <div className="bg-white rounded-[3rem] overflow-hidden shadow-sm border border-slate-100 flex flex-col">
        {/* Toolbar */}
        <div className="p-8 border-b border-slate-50 flex flex-col lg:flex-row justify-between items-stretch lg:items-center gap-8 bg-white sticky top-0 z-20">
          <div className="flex flex-wrap gap-5 items-center">
            <div className="bg-slate-50 p-2 rounded-[2rem] flex shadow-inner overflow-x-auto no-scrollbar max-w-full border border-slate-100">
              {(['todos', 'caliente', 'tibio', 'frio'] as const).map(filter => (
                <button
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className={`px-7 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                    activeFilter === filter ? 'bg-white text-slate-900 shadow-lg ring-1 ring-black/5' : 'text-slate-400 hover:text-slate-600'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
            
            <div className="relative">
                <select 
                value={sortBy} 
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-white border border-slate-200 text-[10px] font-black uppercase tracking-widest text-slate-500 rounded-2xl px-6 py-4 outline-none hover:border-indigo-200 transition-all shadow-sm cursor-pointer appearance-none min-w-[180px]"
                >
                <option value="date">Recientes</option>
                <option value="price_asc">Presupuesto ↑</option>
                <option value="price_desc">Presupuesto ↓</option>
                </select>
                <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-300">
                    <ArrowRight size={14} className="rotate-90" />
                </div>
            </div>
          </div>
          
          <div className="relative group w-full lg:w-[450px]">
            <Search size={18} className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" />
            <input
              type="text"
              placeholder="Buscar por nombre o interés..."
              className="w-full pl-16 pr-8 py-5 rounded-[2.2rem] bg-slate-50/50 border border-slate-100 text-sm font-bold text-slate-700 outline-none focus:ring-[10px] focus:ring-indigo-50/50 focus:border-indigo-100 transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {/* Table View */}
        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full text-left border-collapse min-w-[1000px]">
            <thead className="bg-slate-50/30 text-[10px] uppercase text-slate-400 font-black tracking-[0.3em] border-b border-slate-50">
              <tr>
                <th className="px-10 py-7">Perfil del Prospecto</th>
                <th className="px-10 py-7">Tipo de Interés</th>
                <th className="px-10 py-7">Pipeline / Status</th>
                <th className="px-10 py-7">Inteligencia AgentBot</th>
                <th className="px-10 py-7 text-right">Detalle</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredLeads.length > 0 ? filteredLeads.map((lead, idx) => (
                <motion.tr
                  key={lead.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  onClick={() => setSelectedLead(lead)}
                  className="group hover:bg-slate-50/50 transition-all cursor-pointer border-l-4 border-l-transparent hover:border-l-indigo-600"
                >
                  <td className="px-10 py-8">
                    <div className="flex items-center gap-5">
                      <div className="w-12 h-12 rounded-[1.2rem] bg-slate-900 text-white flex items-center justify-center font-black text-sm shadow-xl group-hover:scale-110 group-hover:rotate-3 transition-all duration-500 ring-2 ring-white">
                        {lead.nombre.charAt(0)}
                      </div>
                      <div>
                        <p className="text-[15px] font-black text-slate-800 group-hover:text-indigo-600 transition-colors leading-none mb-2">{lead.nombre}</p>
                        <div className="flex items-center gap-2">
                           <Smartphone size={10} className="text-slate-400"/>
                           <p className="text-[11px] text-slate-400 font-bold tracking-tight">{lead.telefono}</p>
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-10 py-8">
                    <div className="flex flex-col">
                      <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1.5">{lead.tipo_operacion_preferida}</span>
                      <span className="text-sm font-black text-slate-700 leading-none">{lead.tipo_inmueble_preferido || 'Dpto'}</span>
                    </div>
                  </td>
                  <td className="px-10 py-8">
                    <div className="flex gap-3">
                      <span className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-sm ${statusColors[lead.temperatura]}`}>
                        {lead.temperatura}
                      </span>
                      <span className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-sm ${stageColors[lead.etapa_venta]}`}>
                        {lead.etapa_venta.replace('_', ' ')}
                      </span>
                    </div>
                  </td>
                  <td className="px-10 py-8">
                    <div className="flex items-center gap-4">
                      <div className="w-24 h-2 bg-slate-100 rounded-full overflow-hidden shadow-inner border border-slate-50">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${lead.score_interes * 10}%` }}
                          className={`h-full rounded-full shadow-[0_0_10px_rgba(99,102,241,0.4)] ${lead.score_interes > 7 ? 'bg-emerald-500' : lead.score_interes > 4 ? 'bg-indigo-500' : 'bg-rose-500'}`} 
                        />
                      </div>
                      <span className="text-[11px] font-black text-slate-900 tracking-widest">{lead.score_interes}/10</span>
                    </div>
                  </td>
                  <td className="px-10 py-8 text-right">
                    <div className="p-3.5 text-slate-200 group-hover:text-indigo-600 transition-all hover:bg-white hover:shadow-lg rounded-[1.2rem] inline-block border border-transparent hover:border-slate-100">
                      <ArrowRight size={20} strokeWidth={3} />
                    </div>
                  </td>
                </motion.tr>
              )) : (
                <tr>
                  <td colSpan={5} className="py-48 text-center bg-slate-50/20">
                      <Users size={64} className="mx-auto mb-8 text-slate-200 animate-pulse" />
                      <p className="text-slate-400 font-black uppercase tracking-[0.4em] text-lg">No se han encontrado prospectos</p>
                      <button onClick={() => {setSearchTerm(''); setActiveFilter('todos');}} className="mt-6 text-indigo-600 font-black uppercase text-xs tracking-widest hover:underline">Reiniciar Búsqueda</button>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Leads;
