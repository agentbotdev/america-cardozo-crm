import React, { useState } from 'react';
import { Mail, MessageCircle, AlertTriangle, FileText, Search, ChevronRight, LifeBuoy, Plus, X } from 'lucide-react';

interface ContactOptionProps {
  icon: React.ElementType;
  title: string;
  desc: string;
  actionLabel: string;
  onClick: () => void;
  colorClass: string;
  bgClass: string;
}

const ContactOption: React.FC<ContactOptionProps> = ({ icon: Icon, title, desc, actionLabel, onClick, colorClass, bgClass }) => (
  <div className="glass-card p-6 rounded-3xl flex items-start gap-5 hover:-translate-y-1 transition-transform duration-300">
    <div className={`p-4 rounded-2xl ${bgClass} ${colorClass} shadow-sm`}>
      <Icon size={28} />
    </div>
    <div className="flex-1">
      <h3 className="text-lg font-bold text-gray-800 mb-1">{title}</h3>
      <p className="text-sm text-gray-500 mb-6">{desc}</p>
      <button 
        onClick={onClick}
        className="text-sm font-bold bg-white hover:bg-gray-50 text-gray-700 px-6 py-3 rounded-xl border border-gray-200 transition-colors shadow-sm w-full"
      >
        {actionLabel}
      </button>
    </div>
  </div>
);

const TicketModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
             <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={onClose}></div>
             <div className="glass-modal w-full max-w-lg rounded-3xl shadow-2xl relative animate-fade-in p-8">
                 <div className="flex justify-between items-center mb-6">
                     <h2 className="text-xl font-bold text-gray-800">Nuevo Ticket</h2>
                     <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full" aria-label="Cerrar"><X size={20}/></button>
                 </div>
                 <div className="space-y-4">
                     <div>
                         <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Asunto</label>
                         <input type="text" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-100" placeholder="Ej: Error al cargar propiedades" />
                     </div>
                     <div>
                         <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Categoría</label>
                         <select className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none">
                             <option>Error Técnico</option>
                             <option>Facturación</option>
                             <option>Consulta General</option>
                         </select>
                     </div>
                      <div>
                         <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Descripción</label>
                         <textarea className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-100 min-h-[120px]" placeholder="Describe tu problema en detalle..." />
                     </div>
                 </div>
                 <button onClick={() => { alert('Ticket enviado'); onClose(); }} className="mt-6 w-full py-3 rounded-xl text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-lg shadow-indigo-200">
                     Enviar Ticket
                 </button>
             </div>
        </div>
    )
}

const Support: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'contact' | 'tickets' | 'resources'>('contact');
  const [isTicketModalOpen, setIsTicketModalOpen] = useState(false);

  const handleEmail = () => window.open('mailto:agentbot.ai@gmail.com');
  const handleWhatsApp = () => window.open('https://wa.me/5493517636957', '_blank');
  const handleReport = () => alert('Abriendo chatbot de reporte de errores...');

  return (
    <div className="max-w-5xl mx-auto pb-12 animate-fade-in">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 tracking-tight">Centro de Soporte</h1>
        <p className="text-gray-500 mt-2">¿En qué podemos ayudarte hoy?</p>
      </div>

      <TicketModal isOpen={isTicketModalOpen} onClose={() => setIsTicketModalOpen(false)} />

      {/* Tabs */}
      <div className="glass-card p-1.5 rounded-2xl mb-8 flex w-fit bg-white/40">
        <button 
          onClick={() => setActiveTab('contact')}
          className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'contact' ? 'bg-white shadow-sm text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
        >
          <LifeBuoy size={18} /> Contacto
        </button>
        <button 
          onClick={() => setActiveTab('tickets')}
          className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'tickets' ? 'bg-white shadow-sm text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
        >
          <MessageCircle size={18} /> Mis Tickets
        </button>
        <button 
          onClick={() => setActiveTab('resources')}
          className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 ${activeTab === 'resources' ? 'bg-white shadow-sm text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
        >
          <FileText size={18} /> Recursos
        </button>
      </div>

      {/* Content */}
      <div className="min-h-[400px]">
        {activeTab === 'contact' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
            <ContactOption 
              icon={Mail}
              title="Enviar Email"
              desc="agentbot.ai@gmail.com"
              actionLabel="Enviar Email"
              colorClass="text-blue-600"
              bgClass="bg-blue-50"
              onClick={handleEmail}
            />
            <ContactOption 
              icon={AlertTriangle}
              title="Reportar Errores"
              desc="Reporta bugs vía chatbot"
              actionLabel="Reportar Error"
              colorClass="text-red-600"
              bgClass="bg-red-50"
              onClick={handleReport}
            />
            <ContactOption 
              icon={MessageCircle}
              title="WhatsApp Soporte"
              desc="+54 9 351 763-6957"
              actionLabel="Enviar Mensaje"
              colorClass="text-green-600"
              bgClass="bg-green-50"
              onClick={handleWhatsApp}
            />
          </div>
        )}

        {activeTab === 'tickets' && (
          <div className="glass-card rounded-3xl overflow-hidden animate-fade-in">
            <div className="p-12 text-center text-gray-500 flex flex-col items-center">
              <div className="w-20 h-20 bg-indigo-50 rounded-full flex items-center justify-center mb-6">
                <FileText size={32} className="text-indigo-300"/>
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">No tienes tickets abiertos</h3>
              <p className="mb-8 max-w-sm">Si tienes un problema técnico, crea un ticket y nuestro equipo te responderá pronto.</p>
              <button onClick={() => setIsTicketModalOpen(true)} className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white px-8 py-3 rounded-2xl font-bold shadow-xl shadow-indigo-200 hover:scale-105 transition-transform flex items-center gap-2">
                  <Plus size={20}/> Crear Nuevo Ticket
              </button>
            </div>
          </div>
        )}

        {activeTab === 'resources' && (
          <div className="space-y-6 animate-fade-in">
            <div className="relative glass-card rounded-2xl p-1">
              <Search className="absolute left-5 top-4 text-gray-400" size={20} />
              <input 
                type="text" 
                placeholder="Buscar artículos de ayuda..." 
                className="w-full pl-12 pr-4 py-3 bg-white/50 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-100 transition-colors"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {['Guía de inicio rápido', 'Integración WhatsApp API', 'Configuración Tokko Broker', 'Gestión de Leads Avanzada', 'Pipeline de Ventas'].map((item) => (
                <div key={item} className="glass-card p-5 rounded-2xl hover:border-indigo-300 cursor-pointer flex justify-between items-center group transition-colors">
                  <div className="flex items-center gap-3">
                      <div className="p-2 bg-indigo-50 rounded-lg text-indigo-500"><FileText size={18}/></div>
                      <span className="font-bold text-gray-700 group-hover:text-indigo-600 transition-colors">{item}</span>
                  </div>
                  <ChevronRight size={18} className="text-gray-300 group-hover:text-indigo-500 transition-transform group-hover:translate-x-1" />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Support;