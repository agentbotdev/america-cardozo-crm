
// Usuario / perfiles
export type UserRole = 'admin' | 'vendedor' | 'readonly';

export interface Profile {
  id: string;
  nombre: string;
  email: string;
  rol: UserRole;
  telefono?: string;
  avatar_url?: string;
  created_at: string;
  updated_at: string;
}

// Propiedades
export type OperationType = 'venta' | 'alquiler';
export type PropertyType = 'casa' | 'departamento' | 'ph' | 'local' | 'lote' | 'oficina' | 'otro';
export type PropertyStatus = 'borrador' | 'publicada' | 'pausada' | 'reservada' | 'vendida' | 'alquilada';
export type PropertyAcquisitionStage = 'valoracion' | 'documentacion' | 'fotos' | 'marketing' | 'publicada';
export type PropertyOrigin = 'propia' | 'red1000' | 'red25000';

export interface PropertyPortalIds {
  zonaprop?: string;
  mercadolibre?: string;
  argenprop?: string;
}

export interface Property {
  id: string;
  codigo?: string;
  tipo_operacion: OperationType;
  tipo_inmueble: PropertyType;
  titulo: string;
  descripcion: string;
  
  // Ubicación
  direccion: string;
  barrio: string;
  ciudad: string;
  provincia: string;
  latitud?: number;
  longitud?: number;

  // Precio
  precio: number;
  moneda: 'USD' | 'ARS';
  gastos_mensuales?: number; // Expensas

  // Superficies
  superficie_total?: number;
  superficie_cubierta?: number;
  superficie_semicubierta?: number;
  superficie_descubierta?: number;
  
  // Características
  ambientes?: number;
  dormitorios?: number;
  banos?: number;
  toilettes?: number;
  cocheras?: number;
  antiguedad?: number;
  disposicion?: 'frente' | 'contrafrente' | 'interno' | 'lateral';
  orientacion?: 'N' | 'S' | 'E' | 'O' | 'NE' | 'NW' | 'SE' | 'SW';

  // Amenities & Extras
  amenities?: string[]; // Piscina, SUM, Gimnasio, etc.
  servicios?: string[]; // Agua, Luz, Gas, Internet

  estado_publicacion: PropertyStatus;
  acquisition_stage?: PropertyAcquisitionStage; // Para propiedades en captación
  acquisition_progress?: number; // 0-100
  origen: PropertyOrigin;
  portal_ids?: PropertyPortalIds;
  propietario_nombre?: string;
  propietario_contacto?: string;
  ttk_id?: string;
  imagen_principal?: string;
  imagenes?: string[];
  created_at: string;
  updated_at: string;
  leads_interesados_count?: number;
}

// Leads & Chat
export interface ChatMessage {
  id: string;
  sender: 'user' | 'agent' | 'bot';
  text: string;
  timestamp: string;
  type?: 'text' | 'image' | 'audio';
}

export type ClientStatus = 'frio' | 'interesado' | 'en_seguimiento' | 'cerrado' | 'derivacion_humano' | 'rechazado';
export type SalesStage = 'inicio' | 'indagacion' | 'bajada_producto' | 'pre_cierre' | 'cierre' | 'derivacion_humano' | 'visita_agendada';

export type LeadSource = 'portales' | 'whatsapp' | 'redes' | 'referido' | 'prospeccion' | 'otro';

export interface LeadHistory {
  id: string;
  type: 'stage_change' | 'note' | 'communication' | 'visit' | 'derivation' | 'ticket';
  stage?: string;
  date: string;
  title: string;
  description?: string;
  user_id?: string;
  user_name?: string;
}

export interface Lead {
  id: string;
  nombre: string;
  telefono: string;
  email?: string;
  tipo_operacion_preferida: OperationType | 'ambos';
  rango_presupuesto_min?: number;
  rango_presupuesto_max?: number;
  zonas_preferidas?: string[];
  tipo_inmueble_preferido?: PropertyType;
  plazo_mudanza_dias?: number;
  
  estado_lead: ClientStatus; 
  etapa_venta: SalesStage;

  temperatura: 'frio' | 'tibio' | 'caliente'; 
  score_interes: number; // 0–10
  fuente: LeadSource;
  property_interes_ids?: string[]; 
  properties_offered_ids?: string[]; 
  asesor_asignado_id?: string;
  asesor_nombre?: string;
  notas?: string;
  tags?: string[];
  ai_summary?: string;
  ai_next_step?: string;
  history?: LeadHistory[];
  transcript?: ChatMessage[];
  created_at: string;
  updated_at: string;
}

// Clientes
export type ClientType = 'comprador' | 'inquilino' | 'propietario' | 'inversor';

export interface Client extends Lead {
  tipo_cliente: ClientType;
  estado_comercial: 'activo' | 'inactivo' | 'vip'; 
  wallink?: string;
  ultimo_contacto?: string;
  total_operaciones?: number;
  valor_lifetime?: number;
}

// Visitas
export type VisitStatus = 'agendada' | 'confirmada' | 'en_curso' | 'realizada' | 'cancelada' | 'reprogramada';
export type VisitPipelineStage = 'pendiente' | 'preparacion' | 'seguimiento' | 'finalizada';

export interface VisitTimeline {
  id: string;
  status: VisitStatus;
  timestamp: string;
  comment?: string;
}

export interface Visit {
  id: string;
  lead_id: string;
  lead_nombre: string;
  property_id: string;
  property_titulo: string;
  vendedor_id: string;
  fecha: string; 
  hora: string; 
  estado: VisitStatus;
  pipeline_stage: VisitPipelineStage;
  notas?: string;
  timeline?: VisitTimeline[];
  created_at: string;
  updated_at: string;
}

// Stats for dashboard
export interface DashboardStats {
  totalLeads: number;
  qualifiedLeads: number;
  visitsScheduled: number;
  dealsClosed: number;
  negotiationAmount: number;
  trend?: string; 
  delay?: number;
}