import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import AppLayout from './components/AppLayout';
import Dashboard from './pages/Dashboard';
import Properties from './pages/Properties';
import Leads from './pages/Leads';
import Clients from './pages/Clients';
import Visits from './pages/Visits';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import Support from './pages/Support';

// Placeholder components
const LiveChat = () => <div className="p-6"><h1 className="text-2xl font-bold mb-4">Live Chat</h1><p>Integración con WhatsApp/Chatwoot pendiente.</p></div>;

const App: React.FC = () => {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<AppLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="propiedades" element={<Properties />} />
          <Route path="leads" element={<Leads />} />
          <Route path="clientes" element={<Clients />} />
          <Route path="visitas" element={<Visits />} />
          <Route path="reportes" element={<Reports />} />
          <Route path="soporte" element={<Support />} />
          <Route path="live-chat" element={<LiveChat />} />
          <Route path="configuracion" element={<Settings />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </HashRouter>
  );
};

export default App;
